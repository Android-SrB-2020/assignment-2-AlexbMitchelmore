package com.nbcc.assignment2_am

data class Question (
    val TextResId: Int,
    val answser : Boolean
)